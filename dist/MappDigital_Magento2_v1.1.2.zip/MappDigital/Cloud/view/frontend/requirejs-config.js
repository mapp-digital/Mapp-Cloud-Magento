var config = {
    paths: {
        'wtSmart': 'MappDigital_Cloud/js/smartpixel.min'
    }
};